# Frontend Guideline - Boonraksa System

คู่มือการพัฒนาและหลักการออกแบบส่วนหน้าจอ (UX/UI) ของระบบ Boonraksa

## 🎨 ธีมและสถาปัตยกรรมงานออกแบบ (Design System)

ระบบถูกออกแบบภายใต้แนวคิด **"Professional, Compact, Ultra-Efficient"** ซึ่งเหมาะสำหรับระบบ ERP ที่ต้องการแสดงผลข้อมูลจำนวนมากในพื้นที่จำกัด

### Core Design Principles

- **High Density (ความหนาแน่นสูง)**: ลดช่องว่าง (Spacing) และขนาดฟอนต์ (Base 13px) เพื่อให้เห็นข้อมูลในหน้าจอเดียวได้มากที่สุด
- **Sharp Aesthetics**: ใช้ Border Radius ขนาดเล็ก (6px หรือ `rounded-md`) เพื่อให้ความรู้สึกที่เป็นทางการและเป็นระบบบริหารจัดการ
- **Color Pallet**:
  - `Primary`: Slate 900 (#0f172a) - สีน้ำเงินเข้มขรึม
  - `Accent`: Indigo 600 (#4f46e5) - สีม่วงน้ำเงินสำหรับจุดเด่น
  - `Background`: Slate 50 (#F8FAFC) - พื้นหลังสีนวลตา ลดความล้าของสายตา

### Tailwind CSS Tokens (v4)

เราใช้ CSS Variables ในการควบคุม UI ให้สอดคล้องกันทั่วทั้งระบบ:

- `--color-erp-navy`: พื้นฐานของ Sidebar และ Header หลัก
- `--radius-erp`: ระยะโค้งที่กำหนดไว้ 0.375rem
- `.erp-button`: ปุ่มมาตรฐานแบบกระชับ (Compact)
- `.erp-card`: คาร์ดแบบมีเส้นขอบบางและเงาเบาๆ

## 📱 ความสามารถในการแสดงผล (Responsiveness)

ระบบรองรับ 2 โหมดการใช้งานหลัก:

1. **Desktop Mode**: สำหรับฝ่ายขาย กราฟิก และผู้บริหาร (เน้น Dashboard และการคีย์ข้อมูล)
2. **Mobile View**: สำหรับฝ่ายผลิต และ QC (เน้นปุ่มขนาดใหญ่ที่กดง่าย และการดูสถานะงานที่รวดเร็ว)

## 📂 โครงสร้างส่วนประกอบ (Components)

อยู่ภายใต้ `client/src/`:

- **pages/**: แบ่งตามบทบาท (Role) เช่น `sales/`, `stock/`, `production/`
- **components/**:
  - `Sidebar.jsx`: เมนูหลักที่ย่อ-ขยายได้
  - `ProtectedRoute.jsx`: จัดการสิทธิ์การเข้าถึงหน้าต่างๆ
  - `charts/`: คอมโพเนนต์กราฟแสดงผลผู้บริหาร
- **context/**: `AuthContext.jsx` สำหรับเก็บ Token และข้อมูล User ที่ Login อยู่

## 📡 การเชื่อมต่อข้อมูล (Data Connection)

- ใช้ **Axios** ในการรับส่งข้อมูลกับ Backend API
- จัดการ API Base URL ผ่านไฟล์ config
- มีระบบดักจับ Error (Interceptors) เพื่อแจ้งเตือนผู้ใช้งานเมื่อ Token หมดอายุหรือ Server มีปัญหา

---

> [!IMPORTANT]
> **การแก้ไข UI ในหน้าใหม่**: ควรใช้ Utility Classes จาก `index.css` (เช่น `.erp-input`, `.erp-table`) เป็นหลัก เพื่อรักษาความเป็นเอกภาพของระบบ
