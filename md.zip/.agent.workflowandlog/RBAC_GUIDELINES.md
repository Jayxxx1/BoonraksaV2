# 🛡️ ระบบการควบคุมสิทธิ์ตามบทบาท (RBAC Guidelines)

เอกสารฉบับนี้จัดทำขึ้นเพื่อเป็นแนวทางปฏิบัติสำหรับการพัฒนาและรักษาระบบการควบคุมสิทธิ์ภายใน Boonraksa System ให้มีความปลอดภัยระดับ Production

## 1. หลักการสิทธิ์ขั้นต่ำ (Principle of Least Privilege)

- **ห้าม** ให้สิทธิ์เข้าถึงใดๆ โดยไม่มีความจำเป็นต่องานใน Role นั้น
- **URL Protection**: ทุก Route ในหน้าบ้าน (Frontend) จะต้องถูกครอบด้วย `ProtectedRoute` และระบุ `allowedRoles` เสมอ
- **Backend Enforcement**: ห้ามเชื่อถือเพียงแค่การซ่อนปุ่มจาก Frontend จะต้องมีการตรวจสอบ Role ใน Controller ของ Backend ทุกครั้งสำหรับ Operation ที่สำคัญ (Create, Update, Delete)

## 2. โครงสร้างการเข้าถึงหน้าจอ (Route Mapping)

- **ฝ่านขาย (SALES/MARKETING)**: จัดการออเดอร์, เช็คสต็อก, ติดตามยอดขาย
- **ฝ่ายเทคนิค (GRAPHIC/PRODUCTION/QC)**: ดำเนินงานตามออเดอร์ (เข้าถึงหน้า Order Detail ได้เพื่อดูสเปค) แต่ห้ามเข้าถึงหน้ารวมออเดอร์หรือหน้า Dashboard ฝ่ายขาย
- **ฝ่ายบริหาร (EXECUTIVE/ADMIN)**: ตรวจสอบภาพรวมและรายงาน (Monitor)

## 3. ขั้นตอนเมื่อเพิ่มหน้าใหม่ (New Route Checklist)

1. กำหนด Role ที่ควรเข้าถึงหน้านั้นๆ ใน `App.jsx`
2. ใช้ `ProtectedRoute` ครอบ Route พร้อมส่ง `allowedRoles`
3. ตรวจสอบเงื่อนไขใน `Sidebar.jsx` ให้สอดคล้องกับ `App.jsx`
4. หากมีการส่ง Request ไปยัง Backend ให้เพิ่ม middleware หรือ Logic ตรวจสอบ Role ใน API ด้วย

---

> [!WARNING]
> การปล่อยให้เข้าถึง URL ได้โดยตรงโดยไม่มีการดักสิทธิ์ ถือเป็นความเสี่ยงด้านความปลอดภัยระดับวิกฤต (Critical Vulnerability)
