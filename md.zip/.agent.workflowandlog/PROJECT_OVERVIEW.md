# Boonraksa System - Project Overview

ระบบจัดการโรงงานปัก-สกรีนเสื้อผ้าสมัยใหม่ (Mini ERP) ที่เน้นความรวดเร็ว แม่นยำ และรองรับการทำงานแบบเรียลไทม์ทุกแผนก

## 🎯 วัตถุประสงค์ (Purpose)

- ติดตามสถานะออเดอร์ตั้งแต่การรับงาน (Sales) จนถึงการจัดส่ง (Delivery)
- จัดการสต็อกสินค้าและวัตถุดิบ (Stock Management)
- ควบคุมการผลิตและรายงานประสิทธิภาพรายวัน (Production & Reporting)
- เชื่อมต่อข้อมูลทุกฝ่ายให้เป็นหนึ่งเดียว ลดความผิดพลาดจากกระดาษหรือแชท

## 🏗️ โครงสร้างสถาปัตยกรรม (Architecture)

ระบบถูกออกแบบมาเป็น Client-Server Architecture แบบแยกส่วนชัดเจน:

- **Client (Frontend)**: Single Page Application (SPA) พัฒนาด้วย React และ Tailwind CSS เน้นการใช้งานทั้งบน Desktop และ Mobile (High-Density UI)
- **Server (Backend)**: RESTful API พัฒนาด้วย Node.js/Express.js พร้อมระบบ Schema-based validation
- **Database**: PostgreSQL บริหารจัดการผ่าน Prisma ORM
- **File Storage**: รองรับการอัปโหลดไฟล์ผ่าน AWS S3 (Production) และ Local Storage (Development)

## 🛠️ เทคโนโลยีที่ใช้ (Tech Stack)

### Frontend

- **React 19**: หัวใจหลักในการสร้าง UI
- **Vite**: เครื่องมือ build ที่ทันสมัยและรวดเร็ว
- **Tailwind CSS v4**: สำหรับการดีไซน์ที่มีความยืดหยุ่นสูง
- **React Router 7**: จัดการเส้นทางหน้าเว็บ (Routing)
- **React Icons**: ชุดไอคอนที่สอดคล้องกับแบรนด์

### Backend

- **Node.js**: Runtime environment
- **Express.js**: Framework สำหรับ API
- **Prisma ORM**: จัดการ Schema และ Query ข้อมูลในฐานะ Database Interface
- **PostgreSQL**: ระบบฐานข้อมูลหลักแบบ Relational
- **Puppeteer**: ใช้สำหรับ Generate เอกสาร PDF
- **Zod**: ตรวจสอบความถูกต้องของข้อมูล (Schema Validation)

## 📁 โครงสร้างโฟลเดอร์หลัก (Project Structure)

```text
/
├── client/          # ส่วนหน้าบ้าน (Frontend)
│   ├── src/
│   │   ├── pages/   # หน้าจอแยกตามแผนก (Auth, Sales, Stock, Graphic, etc.)
│   │   ├── comp/    # ส่วนประกอบ UI ส่วนกลาง
│   │   ├── api/     # การเชื่อมต่อ API (Axios/Fetch)
│   │   └── context/ # จัดการ Global State (AuthContext)
├── server/          # ส่วนหลังบ้าน (Backend)
│   ├── routes/      # กำหนด API Endpoints
│   ├── controllers/ # ตรรกะการทำงาน (Logic) ของแต่ละโมดูล
│   ├── prisma/      # Schema ฐานข้อมูลและสคริปต์ Migration
│   └── src/         # Config, Middleware, Services
└── PROJECT_OVERVIEW.md # ไฟล์ปัจจุบัน (Main Entry)
```

---

> [!TIP]
> สำหรับรายละเอียดเชิงลึกในแต่ละส่วน สามารถอ่านเพิ่มเติมได้ที่:
>
> - [Frontend Guideline](file:///d:/BoonraksaSystem/FRONTEND_GUIDE.md)
> - [Backend Guideline](file:///d:/BoonraksaSystem/BACKEND_GUIDE.md)
> - [Workflow Logic](file:///d:/BoonraksaSystem/WORKFLOW_LOGIC.md)
