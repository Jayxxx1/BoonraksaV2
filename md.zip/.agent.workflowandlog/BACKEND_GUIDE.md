# Backend Guideline - Boonraksa System

คู่มือการทำงานของส่วน Server และฐานข้อมูล สำหรับระบบ Boonraksa

## 🏗️ โครงสร้าง API (API Architecture)

Backend พัฒนาด้วย Express.js แบบ Modular โดยแยกหน้าที่ชัดเจน:

- **Routes (`/routes`)**: กำหนดจุดเชื่อมต่อ (Endpoints) แยกตามฟังก์ชัน (เช่น `/api/orders`, `/api/products`)
- **Controllers (`/controllers`)**: เก็บ Logic การทำงานหลักของระบบ
- **Middleware (`/src/middleware`)**: ตรวจสอบสิทธิ์ (JWT), จัดการไฟล์ (Multer), และจัดการ Error
- **Services (`/services`)**: ระบบ PDF Generation หรือการจัดการคลังไฟล์

## 📊 โครงสร้างฐานข้อมูล (Database Schema)

เราใช้ PostgreSQL และ Prisma ORM ในการจัดการข้อมูลหลัก:

### Key Models (โมเดลสำคัญ)

- **Order**: ตัวแทนของใบงาน (Job) เก็บข้อมูลลูกค้า, รายละเอียดปัก/สกรีน และสถานะ
- **User**: เก็บข้อมูลพนักงานและบทบาท (Role) ในระบบ
- **Product & ProductVariant**: จัดการคลังสินค้าแบบ SKU-level
- **ActivityLog**: บันทึกการกระทำทุกอย่างที่เกิดขึ้นกับออเดอร์เพื่อการตรวจสอบ (Audit Trail)
- **ProductionLog**: เก็บเวลาเริ่ม-จบงานของฝ่ายผลิตรายบุคคล

### Status Flow (Enums)

สถานะของงานถูกควบคุมผ่าน **OrderStatus** เพื่อความแม่นยำ:

- `PENDING_ARTWORK` → `DESIGNING` → `PENDING_STOCK_CHECK` → ... → `COMPLETED`

## 🔐 ระบบความปลอดภัย (Security)

- **Authentication**: ใช้ JSON Web Token (JWT) ในทุก API ที่มีความสำคัญ
- **Role-based Access Control (RBAC)**: กำหนดว่าใครทำอะไรได้บ้าง (เช่น Sales แก้ไขราคาได้, Graphic อัปโหลดไฟล์ได้เท่านั้น)
- **Input Validation**: ใช้ `Zod` ตรวจสอบข้อมูลก่อนลง Database เสมอ

## 📁 การจัดการไฟล์ (Storage)

- **Development**: ไฟล์จะอยู่ที่โฟลเดอร์ `server/uploads`
- **Production**: รองรับการย้ายไปใช้ NIPA Cloud Storage หรือ AWS S3 โดยเปลี่ยน Config เพียงจุดเดียว

---

> [!CAUTION]
> **Database Migrations**: ทุกครั้งที่มีการแก้ไข `schema.prisma` จะต้องรันคำสั่ง `npx prisma migrate dev` เพื่ออัปเดตโครงสร้างฐานข้อมูล และ **ห้ามแก้ไข DB โดยตรง** ผ่าน Tool อื่นๆ
